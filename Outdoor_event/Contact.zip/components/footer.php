<footer class="footer" style="background-color: #050505; height:10rem">
    <div class="content has-text-centered">
        <div class="columns" >
            <div class="column">
                <p style="color:#f7eed1;"><a href="MentionLegale.php" style="color:#f7eed1;">Mentions Légales</a> | <a href="ConditionGeneraleVente.php" style="color:#f7eed1;">Conditions Générales de Ventes</a> | <a href="mailto:contact@outdooreventsinprovence.org" style="color:#f7eed1;">Contact</a> | <a href="QuiSommesNous.php" style="color:#f7eed1;">Qui sommes nous ?</a></p>
                <p style=" color:#f7eed1;">Copyright OUTDOOR EVENTS IN PROVENCE</p>
            </div>
        </div>
    </div>
</footer>
<!DOCTYPE html>
<html>

<head>
    <?php include("components/header.php")?>
</head>

<body>
    <?php include("components/navbar.php")?>

    <section class="tile-home ipad" style="background-image: url(&quot;assets/img/Lure.jpg&quot;);min-width: 0px;height: 379px;background-repeat: no-repeat;background-size: cover;">
        <h1 style="margin-top: -44px;margin-bottom: 13px;color: rgb(255,255,255);">Mentions Légale</h1>
        <!--<h2 style="font-size: 32px;color: rgb(255,255,255);">pour etre bien protégé</h2>-->
    </section>
    <div class="row no-gutters products-grid">
        <div class="col-md-6">
            <div class="text-left product-small iphone-8" style="background-color: rgba(15,85,48,0.75);margin-right: -594px;padding-right: 29px;width: 198%;">
                <p class="text-center" style="font-family: 'Zen-Its Sans';margin-left: 29px;margin-right: 29 px;color: rgb(255,255,255);"><br>thpacademie.com un site édité par :<br>Outdoor Events In Provence<br>Association loi 1901 créée en 2013<br>contact@thpacademie.com<br>06.74.71.35.23<br><br>SIRET 798 925 426 00016<br><br>Site hébergé parAmen<br><br>AMEN SASU, 12-14,
                    Rond-Point des Champs Elysées 75008 ParisRCS <br>Paris: 421 527 797 000 11-Société au capital social de 37 000 €<br><br></p>
            </div>
        </div>
    </div>
    
    <?php include("components/footer.php")?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>
<div class="session-head-pic">
    <img src="assets/img/Lure.jpg">
</div>
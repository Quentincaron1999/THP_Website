<?php include("banner-page.php")?>
<nav id="navbar-top" class="navbar nav-session is-hidden-mobile" role="navigation" aria-label="main navigation">
	<div id="navbarBasicExample" class="navbar-menu">
    	<div class="navbar-start">
			<h1 class="navbar-item" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Conditions Générales de Ventes</h1>
		</div>
	</div>
</nav>



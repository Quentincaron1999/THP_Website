<?php include("banner-page.php")?>
<nav id="navbar-top" class="navbar nav-session is-hidden-mobile" role="navigation" aria-label="main navigation">
	<div id="navbarBasicExample" class="navbar-menu">
    	<div class="navbar-start">
		<h1 class="navbar-item">Coaching</h1>
        <a class="navbar-item" href="#EnBref" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">En Bref</a>
        <a class="navbar-item" href="#PEP" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Plan d'entraînement personnalisé</a>
		<a class="navbar-item" href="#Nutrition" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Nutrition</a>
		<a class="navbar-item" href="#Yoga" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Yoga</a>
	</div>

    <div class="navbar-end">
      	<div class="navbar-item">
			<a class="button is-primary is-rounded navbar-item" href="https://forms.gle/R2yszeHmvgcrK6Q59" target="_blank" style="color: #f7eed1;">Personnaliser son entraînement</a>
      	</div>
    </div>
</nav>



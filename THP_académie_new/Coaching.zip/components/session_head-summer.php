<div class="session-head-pic">
    <img src="assets/img/summer-session1.jpeg" >
</div>
<nav id="navbar-top" class="navbar nav-session is-hidden-mobile" role="navigation" aria-label="main navigation">
	<div id="navbarBasicExample" class="navbar-menu">
    	<div class="navbar-start">
		<h1 class="navbar-item">Session été</h1>
        <a class="navbar-item" href="#EnBref" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">En Bref</a>
        <a class="navbar-item" href="#Programme" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Programme</a>
		<a class="navbar-item" href="#Niveau" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Niveau</a>
		<a class="navbar-item" href="#LeMateriel" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Le matériel</a>
		<a class="navbar-item" href="#VotreCadre" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Votre Cadre</a>
		<a class="navbar-item" href="#LesPlus" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Les + du séjour</a>
		<a class="navbar-item" href="#Tarif" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Tarif</a>
		<a class="navbar-item" href="#Tem" onmouseover="this.style.background='#d3c495';" onmouseout="this.style.background='#F7EED1';">Témoignages</a>
    </div>

    <div class="navbar-end">
      	<div class="navbar-item">
			<a class="button is-primary is-rounded navbar-item ivoire" target="_blank" href="http://thpacademielestagedetraildu31juilletau2aout2020.ikinoa.com/" style="color: #f7eed1;">S'inscrire</a>
      	</div>
    </div>
</nav>



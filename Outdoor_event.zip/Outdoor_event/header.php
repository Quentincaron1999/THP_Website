<!DOCTYPE html>
<html>
	<head>
		<title>Tesla Clone</title>
		<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
		<link href="style.css" rel="stylesheet">
	</head>
	
	<body>
		<nav class="navbar is-transparent">
			<div class="navbar-brand">
			  <a class="navbar-item" href="https://bulma.io">
				<img src="https://bulma.io/images/bulma-logo.png" alt="Bulma: a modern CSS framework based on Flexbox" width="112" height="28">
			  </a>
			  <div class="navbar-burger burger" data-target="navbarExampleTransparentExample">
				<span></span>
				<span></span>
				<span></span>
			  </div>
			</div>
		  
			<div id="navbarExampleTransparentExample" class="navbar-menu">
			  <div class="navbar-start" style="flex-grow: 1; justify-content: center;">
				<a class="navbar-item" href="https://bulma.io/">
				  Trail de Haute Provence
				</a>
				<a class="navbar-item" href="https://bulma.io/">
					THPrunning
				  </a>
				  <a class="navbar-item" href="https://bulma.io/">
					THPwinter
				  </a>
				  <a class="navbar-item" href="https://bulma.io/">
					THPacadémie
				  </a>
			  </div>
		  
			  <div class="navbar-end">
				<div class="navbar-item">
				  <div class="field is-grouped">
					<p class="control">
					  <a class="button is-primary" href="https://github.com/jgthms/bulma/releases/download/0.9.0/bulma-0.9.0.zip">
						<span class="icon">
						  <i class="fas fa-download"></i>
						</span>
						<span>Download</span>
					  </a>
					</p>
				  </div>
				</div>
			  </div>
			</div>
		  </nav>